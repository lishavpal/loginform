
let localData = localStorage.getItem('userData');
let isLoggedInData = localStorage.getItem('isLoggedIn');
const getContactCls = document.querySelector('.form_container');
let btn = document.querySelector('.displayer');
function localStorageFunc() {    
    if(localData == null) {
        localStorage.setItem('userData', false);
    }

    if(isLoggedInData == null) {
        localStorage.setItem('isLoggedIn', false);
    }
    if(isLoggedInData == 'true') {
        getContactCls.style.display = 'none';
        btn.style.display="block";
    } else {
        getContactCls.style.display = 'block';
        btn.style.display="none";
    }
}

function logOut(){
    let logoutBtn = document.getElementById('btn');
    logoutBtn.addEventListener('click', function() {
        getContactCls.style.display = 'block';
        btn.style.display = 'none';
        if(isLoggedInData == 'true') {
            localStorage.setItem('isLoggedIn', JSON.stringify(false));
        }
    })
}
logOut();
localStorageFunc();

function validateForm() {
    const name = document.myForm.firstname.value;
    const lastname = document.myForm.lastname.value;
    const email = document.myForm.email.value;
    
    if(name == '' || lastname == '' || email == '') {
        if(name == '') {
            alert('firstname cannot be blank')
        } else if(lastname == '') {
            alert('lastname cannot be blank')
        } else if(email == '') {
            alert('email cannot be blank')
        }
    } else {
        
        let objData = {
            firstname : name,
            lastname : lastname,
            email: email,
        }
        //true
        document.getElementById(objData);
        localStorage.setItem('isLoggedIn', JSON.stringify(true));
        getContactCls.style.display = 'none';
        btn.style.display="block";
        
    }
    return false;
  }


